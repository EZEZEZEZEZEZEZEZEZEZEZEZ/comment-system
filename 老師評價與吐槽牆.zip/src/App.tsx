/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, MessageSquareQuote, Ghost, Loader2, AlertTriangle, LogIn } from 'lucide-react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db, auth, signInWithGoogle } from './firebase';
import ReviewCard from './components/ReviewCard';
import ReviewForm from './components/ReviewForm';
import Filters from './components/Filters';

interface Review {
  id: string;
  teacherName: string;
  rating: number;
  content: string;
  category: string;
  likes: number;
  status: 'active' | 'done';
  createdAt: any;
}

export default function App() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('全部');
  const [statusFilter, setStatusFilter] = useState('all');
  const [authErrorCode, setAuthErrorCode] = useState<string | null>(null);

  useEffect(() => {
    const handleAuthError = (e: any) => {
      setAuthErrorCode(e.detail);
    };
    window.addEventListener('firebase-auth-error', handleAuthError);

    // Initial query by time, we will sort status in memory to keep it dynamic and simple
    const q = query(collection(db, 'reviews'), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Review[];
      setReviews(docs);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching reviews:", error);
      setLoading(false);
    });

    return () => {
      unsubscribe();
      window.removeEventListener('firebase-auth-error', handleAuthError);
    };
  }, []);

  const filteredReviews = reviews
    .filter(review => {
      const matchesSearch = review.teacherName.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = category === '全部' || review.category === category;
      const matchesStatus = statusFilter === 'all' || (review.status || 'active') === statusFilter;
      return matchesSearch && matchesCategory && matchesStatus;
    })
    .sort((a, b) => {
      // Sort by status: "active" before "done"
      if ((a.status || 'active') === (b.status || 'active')) {
        // If status same, keep chronological order (descending createdAt)
        const timeA = a.createdAt?.seconds || 0;
        const timeB = b.createdAt?.seconds || 0;
        return timeB - timeA;
      }
      return (a.status || 'active') === 'active' ? -1 : 1;
    });

  const stats = {
    active: reviews.filter(r => (r.status || 'active') === 'active').length,
    done: reviews.filter(r => r.status === 'done').length,
    total: reviews.length
  };

  return (
    <div className="min-h-screen pb-24">
      {/* Auth Error Banner */}
      <AnimatePresence>
        {authErrorCode === 'auth/admin-restricted-operation' && !auth.currentUser && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            className="bg-amber-500/10 border-b border-amber-500/20 overflow-hidden"
          >
            <div className="max-w-5xl mx-auto px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm">
              <div className="flex items-center gap-2 text-amber-500">
                <AlertTriangle size={18} />
                <span>匿名登入未啟用。請在 Firebase 控制台啟用「Anonymous」提供者，或使用 Google 登入。</span>
              </div>
              <button
                onClick={() => signInWithGoogle()}
                className="flex items-center gap-2 px-4 py-1.5 bg-amber-500 text-black font-bold rounded-lg hover:bg-amber-400 transition-colors whitespace-nowrap"
              >
                <LogIn size={16} />
                Google 登入
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Header */}
      <header className="sticky top-0 z-40 bg-zinc-950/80 backdrop-blur-md border-b border-zinc-800/50">
        <div className="max-w-5xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500 rounded-xl">
              <MessageSquareQuote className="text-black" size={24} />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight text-zinc-100">老師評價與吐槽牆</h1>
              <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Teacher Roast Wall</p>
            </div>
          </div>
          <button
            onClick={() => setIsFormOpen(true)}
            className="p-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-amber-500 hover:bg-amber-500 hover:text-black transition-all active:scale-95 sm:hidden"
          >
            <Plus size={20} />
          </button>
          <button
            onClick={() => setIsFormOpen(true)}
            className="hidden sm:flex items-center gap-2 px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-xl transition-all active:scale-95"
          >
            <Plus size={18} />
            發表評價
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 pt-8">
        <Filters 
          search={search} 
          setSearch={setSearch} 
          category={category} 
          setCategory={setCategory} 
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
          stats={stats}
        />

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-zinc-500 gap-4">
            <Loader2 className="animate-spin" size={32} />
            <p className="text-sm font-medium">正在加載評價...</p>
          </div>
        ) : filteredReviews.length > 0 ? (
          <div className="waterfall-grid">
            <AnimatePresence mode="popLayout">
              {filteredReviews.map((review) => (
                <ReviewCard key={review.id} {...review} />
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-zinc-600 gap-4 text-center">
            <Ghost size={64} strokeWidth={1.5} />
            <div>
              <p className="text-lg font-bold text-zinc-400">空空如也</p>
              <p className="text-sm">還沒有人發表評價，快來當第一個吧！</p>
            </div>
            <button
              onClick={() => setIsFormOpen(true)}
              className="mt-2 text-amber-500 font-medium hover:underline"
            >
              立即發表
            </button>
          </div>
        )}
      </main>

      {/* Mobile Floating Action Button */}
      <div className="fixed bottom-8 right-8 sm:hidden z-50">
        <button
          onClick={() => setIsFormOpen(true)}
          className="w-14 h-14 bg-amber-500 rounded-full flex items-center justify-center text-black shadow-2xl shadow-amber-500/40 active:scale-90 transition-transform"
        >
          <Plus size={28} />
        </button>
      </div>

      <ReviewForm isOpen={isFormOpen} onClose={() => setIsFormOpen(false)} />
      
      <footer className="mt-20 py-10 border-t border-zinc-900 text-center">
        <p className="text-zinc-600 text-xs font-medium uppercase tracking-widest">
          匿名評價系統 · 僅供學術交流參考
        </p>
      </footer>
    </div>
  );
}

