import { Search, Filter, Layers } from 'lucide-react';

interface FiltersProps {
  search: string;
  setSearch: (val: string) => void;
  category: string;
  setCategory: (val: string) => void;
  statusFilter: string;
  setStatusFilter: (val: string) => void;
  stats: {
    active: number;
    done: number;
    total: number;
  };
}

const CATEGORIES = ["全部", "教學風格", "功課份量", "評分標準", "其他"];
const STATUS_FILTERS = [
  { label: "全部", value: "all", key: 'total' },
  { label: "只看 active", value: "active", key: 'active' },
  { label: "只看 done", value: "done", key: 'done' }
];

export default function Filters({ 
  search, 
  setSearch, 
  category, 
  setCategory,
  statusFilter,
  setStatusFilter,
  stats
}: FiltersProps) {
  return (
    <div className="space-y-4 mb-8">
      {/* Search Input */}
      <div className="relative group">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 group-focus-within:text-amber-500 transition-colors" size={20} />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="搜尋老師姓名..."
          className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl pl-12 pr-4 py-4 text-zinc-100 focus:outline-none focus:border-amber-500/50 focus:ring-4 focus:ring-amber-500/5 transition-all"
        />
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Status Filter Buttons */}
        <div className="flex items-center gap-3 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-2 text-zinc-500 mr-2 shrink-0">
            <Layers size={16} />
            <span className="text-sm font-medium">狀態:</span>
          </div>
          {STATUS_FILTERS.map((f) => (
            <button
              key={f.value}
              onClick={() => setStatusFilter(f.value)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all border flex items-center gap-2 ${
                statusFilter === f.value
                  ? "bg-amber-500 text-black border-amber-500 shadow-lg shadow-amber-500/20"
                  : "bg-zinc-900 text-zinc-400 border-zinc-800 hover:border-zinc-700"
              }`}
            >
              {f.label}
              <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-black ${
                statusFilter === f.value ? "bg-black/20 text-black" : "bg-zinc-800 text-zinc-500"
              }`}>
                {stats[f.key as keyof typeof stats]}
              </span>
            </button>
          ))}
        </div>

        {/* Live Counter (Simplified for Mobile) */}
        <div className="hidden sm:flex items-center gap-4 text-[10px] font-bold uppercase tracking-tighter text-zinc-500 border-l border-zinc-800 pl-4">
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
            ACTIVE: {stats.active}
          </div>
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-zinc-700"></span>
            DONE: {stats.done}
          </div>
          <div className="flex items-center gap-1 border-l border-zinc-800 pl-4">
            TOTAL: {stats.total}
          </div>
        </div>
      </div>

      {/* Category Filter Buttons */}
      <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar">
        <div className="flex items-center gap-2 text-zinc-500 mr-2 shrink-0">
          <Filter size={16} />
          <span className="text-sm font-medium">分類:</span>
        </div>
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
              category === cat
                ? "bg-amber-500/10 text-amber-500 border border-amber-500/30"
                : "bg-zinc-900 text-zinc-400 border border-zinc-800 hover:border-zinc-700"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>
    </div>
  );
}
