import { useState } from 'react';
import { motion } from 'motion/react';
import { Star, ThumbsUp, Calendar, Tag, CheckCircle2, BookmarkCheck } from 'lucide-react';
import { doc, updateDoc, increment } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { formatDistanceToNow } from 'date-fns';
import { zhTW } from 'date-fns/locale';

interface ReviewCardProps {
  id: string;
  teacherName: string;
  rating: number;
  content: string;
  category: string;
  likes: number;
  status: 'active' | 'done';
  createdAt: any;
}

export default function ReviewCard({
  id,
  teacherName,
  rating,
  content,
  category,
  likes,
  status = 'active',
  createdAt,
}: ReviewCardProps) {
  const [isLiking, setIsLiking] = useState(false);
  const [isTogglingStatus, setIsTogglingStatus] = useState(false);
  const [localLikes, setLocalLikes] = useState(likes);

  const handleLike = async () => {
    if (isLiking) return;
    setIsLiking(true);
    try {
      const reviewRef = doc(db, 'reviews', id);
      await updateDoc(reviewRef, {
        likes: increment(1),
      });
      setLocalLikes(prev => prev + 1);
    } catch (error) {
      console.error("Error liking review:", error);
      try {
        handleFirestoreError(error, OperationType.UPDATE, `reviews/${id}`);
      } catch (e) {
        // Silent fail for likes in UI
      }
    } finally {
      setIsLiking(false);
    }
  };

  const handleToggleStatus = async () => {
    if (isTogglingStatus) return;
    setIsTogglingStatus(true);
    const newStatus = status === 'active' ? 'done' : 'active';
    try {
      const reviewRef = doc(db, 'reviews', id);
      await updateDoc(reviewRef, {
        status: newStatus,
      });
    } catch (error) {
      console.error("Error toggling status:", error);
      try {
        handleFirestoreError(error, OperationType.UPDATE, `reviews/${id}`);
      } catch (e) {
        // Handle error if needed
      }
    } finally {
      setIsTogglingStatus(false);
    }
  };

  const dateLabel = createdAt?.toDate 
    ? formatDistanceToNow(createdAt.toDate(), { addSuffix: true, locale: zhTW })
    : '剛剛';

  const isDone = status === 'done';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ 
        opacity: isDone ? 0.4 : 1, 
        y: 0,
        filter: isDone ? 'grayscale(30%)' : 'grayscale(0%)'
      }}
      className="waterfall-item bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5 hover:border-amber-500/30 transition-all group relative overflow-hidden"
    >
      {isDone && (
        <div className="absolute top-0 right-0 p-2 z-10">
          <div className="bg-amber-500 text-black text-[10px] font-black px-2 py-0.5 rounded shadow-lg flex items-center gap-1">
            <CheckCircle2 size={10} />
            已閱
          </div>
        </div>
      )}

      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="text-lg font-bold text-zinc-100 group-hover:text-amber-400 transition-colors">
            {teacherName}
          </h3>
          <div className="flex gap-0.5 mt-1">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={14}
                className={i < rating ? "fill-amber-500 text-amber-500" : "text-zinc-700"}
              />
            ))}
          </div>
        </div>
        <span className="px-2 py-1 bg-zinc-800 text-zinc-400 text-xs rounded-lg flex items-center gap-1 shrink-0">
          <Tag size={12} />
          {category}
        </span>
      </div>

      <p className="text-zinc-300 text-sm leading-relaxed mb-4 whitespace-pre-wrap">
        {content}
      </p>

      <div className="flex justify-between items-center pt-4 border-t border-zinc-800/50">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-1.5 text-zinc-500 text-[10px]">
            <Calendar size={10} />
            {dateLabel}
          </div>
          
          <button
            onClick={handleToggleStatus}
            disabled={isTogglingStatus}
            className={`flex items-center gap-1.5 text-xs font-bold transition-colors ${
              isDone ? 'text-zinc-500 hover:text-amber-500' : 'text-amber-500/50 hover:text-amber-500'
            }`}
          >
            <BookmarkCheck size={14} />
            {isDone ? '設為未閱' : '標記為已閱'}
          </button>
        </div>
        
        <button
          onClick={handleLike}
          disabled={isLiking}
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-800 hover:bg-amber-500/10 hover:text-amber-500 text-zinc-400 transition-all active:scale-95 disabled:opacity-50"
        >
          <ThumbsUp size={14} className={isLiking ? "animate-bounce" : ""} />
          <span className="text-xs font-medium">{localLikes}</span>
        </button>
      </div>
    </motion.div>
  );
}
