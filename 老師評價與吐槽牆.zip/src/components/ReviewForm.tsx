import { useState, type FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, Star, AlertCircle, LogIn, ExternalLink } from 'lucide-react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType, signInWithGoogle } from '../firebase';

interface ReviewFormProps {
  isOpen: boolean;
  onClose: () => void;
}

const CATEGORIES = ["教學風格", "功課份量", "評分標準", "其他"];

export default function ReviewForm({ isOpen, onClose }: ReviewFormProps) {
  const [teacherName, setTeacherName] = useState('');
  const [rating, setRating] = useState(0);
  const [content, setContent] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!teacherName || !rating || !content) {
      setError('請填寫所有必填欄位');
      return;
    }

    setIsSubmitting(true);
    setError('');

    // If not logged in, try Google Login first
    if (!auth.currentUser) {
      try {
        await signInWithGoogle();
      } catch (err: any) {
        if (err.code === 'auth/admin-restricted-operation') {
          setError('匿名登入受限。請先在 Firebase 控制台啟用 Anonymous 提供者。');
        } else {
          setError('登入失敗，無法提交評價。');
        }
        setIsSubmitting(false);
        return;
      }
    }

    try {
      await addDoc(collection(db, 'reviews'), {
        teacherName,
        rating,
        content,
        category,
        likes: 0,
        status: "active",
        createdAt: serverTimestamp(),
      });
      
      setTeacherName('');
      setRating(0);
      setContent('');
      setCategory(CATEGORIES[0]);
      onClose();
    } catch (err) {
      console.error("Error adding review:", err);
      try {
        handleFirestoreError(err, OperationType.CREATE, 'reviews');
      } catch (jsonErr: any) {
        const info = JSON.parse(jsonErr.message);
        setError('提交失敗：' + info.error);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const isAuthRestricted = error.includes('auth/admin-restricted-operation');

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg bg-zinc-900 border border-zinc-800 rounded-3xl p-6 z-50 shadow-2xl overflow-y-auto max-h-[90vh]"
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-zinc-100">發表評價 / 吐槽</h2>
              <button onClick={onClose} className="p-2 hover:bg-zinc-800 rounded-full text-zinc-400 transition-colors">
                <X size={20} />
              </button>
            </div>

            {isAuthRestricted && (
              <div className="mb-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-sm text-amber-200">
                <p className="font-bold mb-2 flex items-center gap-2">
                  <AlertCircle size={16} />
                  需要啟用匿名登入
                </p>
                <p className="mb-3 opacity-80">您的 Firebase 專案尚未開啟匿名登入功能，這會導致無法匿名提交。</p>
                <a 
                  href="https://console.firebase.google.com/project/gen-lang-client-0730930955/authentication/providers" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-amber-500 hover:underline font-bold"
                >
                  前往控制台開啟 <ExternalLink size={14} />
                </a>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* ... existing fields ... */}
              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-1.5">老師姓名</label>
                <input
                  type="text"
                  value={teacherName}
                  onChange={(e) => setTeacherName(e.target.value)}
                  placeholder="例如：陳大文 老師"
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-1.5">星級評分</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="p-1 transition-transform active:scale-90"
                    >
                      <Star
                        size={28}
                        className={star <= rating ? "fill-amber-500 text-amber-500" : "text-zinc-700"}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-1.5">評價分類</label>
                <div className="flex flex-wrap gap-2">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setCategory(cat)}
                      className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                        category === cat
                          ? "bg-amber-500 text-black"
                          : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-1.5">評價內容</label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="寫下你的評價或吐槽..."
                  rows={4}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-xl px-4 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500 transition-colors resize-none"
                />
              </div>

              {error && !isAuthRestricted && (
                <div className="flex items-center gap-2 text-red-500 text-sm bg-red-500/10 p-3 rounded-xl">
                  <AlertCircle size={16} />
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-amber-500 hover:bg-amber-400 disabled:bg-zinc-700 text-black font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                {isSubmitting ? "處理中..." : (
                  !auth.currentUser ? (
                    <>
                      <LogIn size={18} />
                      使用 Google 登入並提交
                    </>
                  ) : (
                    <>
                      <Send size={18} />
                      匿名提交
                    </>
                  )
                )}
              </button>
            </form>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
